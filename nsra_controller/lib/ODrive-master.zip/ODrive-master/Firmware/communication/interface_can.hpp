#ifndef __INTERFACE_CAN_HPP
#define __INTERFACE_CAN_HPP

//#include <cmsis_os.h>
//#include "odrive_main.h"
//#include "can_helpers.hpp"
//#include <communication/can/can_simple.hpp>
//// Other protocol implementations here

#endif
